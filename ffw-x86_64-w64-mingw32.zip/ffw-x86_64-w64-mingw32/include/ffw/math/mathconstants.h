#ifndef FFW_MATH_CONSTANTS
#define FFW_MATH_CONSTANTS

#endif
